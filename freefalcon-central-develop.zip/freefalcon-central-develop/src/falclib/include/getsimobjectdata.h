#include "entity.h"

SimWeaponDataType *GetSWD(int WeaponId);
Falcon4EntityClassType *GetWeaponF4CT(int WeaponId);
WeaponClassDataType *GetWCD(int WeaponId);
