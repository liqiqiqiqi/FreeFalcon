//
//
//
//   UI.H  -  Copyright (c) 1995, Spectrum HoloByte, Inc.
//
//
//
//


#ifndef __UI_H__
#define __UI_H__

#define UI_TIMER_INTERVAL 1000 // Update timer on 1 second intervals

#endif

