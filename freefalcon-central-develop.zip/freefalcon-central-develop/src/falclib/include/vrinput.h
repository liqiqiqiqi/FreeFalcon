
#ifndef VRINPUT_H
#define VRINPUT_H

// #define VOICE_INPUT 1

extern void InitVoiceRecognitionEngine(void);

extern void InitVoiceRecognitionTopicsFiles(char *path);

extern void DoVoiceRecognitionInput(void);

#endif

