#ifndef _FALCMEM_H
#define _FALCMEM_H

class falcon4LeakCheck
{
public:
    falcon4LeakCheck();
    virtual ~falcon4LeakCheck();
};

#endif
