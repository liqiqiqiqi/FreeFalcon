/*
 * Machine Generated source file for message "Request Persistant List".
 * NOTE: The functions here must be completed by hand.
 * Generated on 29-July-1997 at 18:41:02
 * Generated from file EVENTS.XLS by Kevin Klemmick
 */
/*

//sfr: took this out, not used!!
#include "MsgInc/RequestPersistantList.h"
#include "mesg.h"
#include "falclib.h"
#include "falcmesg.h"
#include "falcgame.h"
#include "falcsess.h"
#include "InvalidBufferException.h"

//sfr: added here for checks
using std::memcpychk;


FalconRequestPersistantList::FalconRequestPersistantList(VU_ID entityId, VuTargetEntity *target, VU_BOOL loopback) : FalconEvent (RequestPersistantList, FalconEvent::CampaignThread, entityId, target, loopback)
{
   // Your Code Goes Here
}

FalconRequestPersistantList::FalconRequestPersistantList(VU_MSG_TYPE type, VU_ID senderid, VU_ID target) : FalconEvent (RequestPersistantList, FalconEvent::CampaignThread, senderid, target)
{
   // Your Code Goes Here
}

FalconRequestPersistantList::~FalconRequestPersistantList(void)
{
   // Your Code Goes Here
}

int FalconRequestPersistantList::Process(void)
{
   // Your Code Goes Here
   return 0;
}

*/
