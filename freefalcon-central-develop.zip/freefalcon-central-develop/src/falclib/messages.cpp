#if 0
/*
 * Machine Generated messages .cpp file.
 * NOTE: This file is read only. DO NOT ATTEMPT TO MODIFY IT BY HAND.
 * Generated on 14-December-1998 at 14:17:03
 * Generated from file EVENTS.XLS by MicroProse
 */
/*

//sfr: took all this out, each CPP has its own file now... This was a bi***
#ifndef _MESSAGESOURCE_H
#define _MESSAGESOURCE_H

#include "falclib.h"
#include "falcmesg.h"
#include "falcgame.h"
#include "falcsess.h"
#include "InvalidBufferException.h"

*/
/*
 * Required .CPP Files
 */
/*
#include "MsgSrc/DamageMsg.cpp"
#include "MsgSrc/WeaponFireMsg.cpp"
#include "MsgSrc/CampWeaponFireMsg.cpp"
#include "MsgSrc/CampMsg.cpp"
#include "MsgSrc/SimCampMsg.cpp"
#include "MsgSrc/UnitMsg.cpp"
#include "MsgSrc/ObjectiveMsg.cpp"
#include "MsgSrc/UnitAssignmentMsg.cpp"
#include "MsgSrc/SendCampaignMsg.cpp"
#include "MsgSrc/TimingMsg.cpp"
#include "MsgSrc/CampTaskingMsg.cpp"
#include "MsgSrc/AirTaskingMsg.cpp"
#include "MsgSrc/GndTaskingMsg.cpp"
#include "MsgSrc/NavalTaskingMsg.cpp"
#include "MsgSrc/TeamMsg.cpp"
#include "MsgSrc/WingmanMsg.cpp"
#include "MsgSrc/AirAIModeChange.cpp"
#include "MsgSrc/MissionRequestMsg.cpp"
#include "MsgSrc/DivertMsg.cpp"
#include "MsgSrc/WeatherMsg.cpp"
#include "MsgSrc/MissileEndMsg.cpp"
#include "MsgSrc/AWACSMsg.cpp"
#include "MsgSrc/FACMsg.cpp"
#include "MsgSrc/ATCMsg.cpp"
#include "MsgSrc/DeathMessage.cpp"
#include "MsgSrc/CampEventMsg.cpp"
#include "MsgSrc/LandingMessage.cpp"
#include "MsgSrc/ControlSurfaceMsg.cpp"
#include "MsgSrc/SimDataToggle.cpp"
#include "MsgSrc/RequestDogfightInfo.cpp"
#include "MsgSrc/SendDogfightInfo.cpp"
#include "MsgSrc/RequestAircraftSlot.cpp"
#include "MsgSrc/SendAircraftSlot.cpp"
#include "MsgSrc/GraphicsTextDisplayMsg.cpp"
#include "MsgSrc/AddSFXMessage.cpp"
#include "MsgSrc/SendPersistantList.cpp"
#include "MsgSrc/SendObjData.cpp"
#include "MsgSrc/SendUnitData.cpp"
#include "MsgSrc/RequestCampaignData.cpp"
#include "MsgSrc/SendChatMessage.cpp"
#include "MsgSrc/TankerMsg.cpp"
#include "MsgSrc/EjectMsg.cpp"
#include "MsgSrc/TrackMsg.cpp"
#include "MsgSrc/CampDataMsg.cpp"
#include "MsgSrc/VoiceDataMsg.cpp"
#include "MsgSrc/RadioChatterMsg.cpp"
#include "MsgSrc/PlayerStatusMsg.cpp"
#include "MsgSrc/LaserDesignateMsg.cpp"
#include "MsgSrc/ATCCmdMsg.cpp"
#include "MsgSrc/DLinkMsg.cpp"
#include "MsgSrc/RequestObject.cpp"
#include "MsgSrc/RegenerationMsg.cpp"
#include "MsgSrc/RequestLogbook.cpp"
#include "MsgSrc/SendLogbook.cpp"
#include "MsgSrc/SendImage.cpp"
#include "MsgSrc/FalconFlightPlanMsg.cpp"
#include "MsgSrc/SimDirtyDataMsg.cpp"
#include "MsgSrc/CampDirtyDataMsg.cpp"
#include "MsgSrc/CampEventDataMsg.cpp"
#include "MsgSrc/SendVCMsg.cpp"
#include "MsgSrc/SendUIMsg.cpp"
#include "MsgSrc/SendEvalMsg.cpp"


#endif
*/
#endif
