/*  Application defined data, etc */

/* comment/uncomment this as wished */
/*#define DEBUG_COMMS */
//#define CAPI_NET_DEBUG_FEATURES
#define COMPRESS_DATA

