/* protofilt.h - Copyright (c) Fri Dec 06 23:42:31 1996,  Spectrum HoloByte, Inc.  All Rights Reserved */
#ifndef _PROTOFILT_H_
#define _PROTOFILT_H_


#include <winsock2.h>

#ifdef __cplusplus
extern "C" {
#endif


    int UseProtocol(IN LPWSAPROTOCOL_INFO Proto);


#ifdef __cplusplus
}
#endif
#endif
