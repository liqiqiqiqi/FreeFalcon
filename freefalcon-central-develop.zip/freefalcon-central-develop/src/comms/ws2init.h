/* ws2init.h - Copyright (c) Fri Dec 06 22:46:01 1996,  Spectrum HoloByte, Inc.  All Rights Reserved */
#ifndef _WS2INIT_H_
#define _WS2INIT_H_

#include <winsock.h>

#ifdef __cplusplus
extern "C" {
#endif


    int initialize_windows_sockets(WSADATA *wsaData);


#ifdef __cplusplus
}
#endif
#endif
