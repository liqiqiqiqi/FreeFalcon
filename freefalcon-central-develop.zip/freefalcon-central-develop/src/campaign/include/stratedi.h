
#ifndef STRATEDI
#define STRATEDI

#include "GUI.h"
#include "Strategy.h"

extern void DisplayStateClass(Window w, CampaignState s);

extern void DisplayState(Window w, CampaignState s);

extern CampaignState EditStates();

#endif
