

#ifndef UNITDIAL_H
#define UNITDIAL_H

extern BOOL CALLBACK SelectMission(HWND, UINT, WPARAM, LPARAM);

extern BOOL WINAPI EditWayPoint(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);

extern BOOL CALLBACK EditUnit(HWND, UINT, WPARAM, LPARAM);

#endif
