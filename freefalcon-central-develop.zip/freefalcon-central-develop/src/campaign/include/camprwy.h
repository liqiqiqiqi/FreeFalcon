
#ifndef CAMPRWY_H
#define CAMPRWY_H


class ObjectiveClass;
typedef ObjectiveClass *Objective;

#endif
