#ifndef BEXPAND_H
#define BEXPAND_H

#define EXPANDER_TOOL

#endif
