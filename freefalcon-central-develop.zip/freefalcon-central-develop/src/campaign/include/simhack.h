#ifndef SIMHACK_H
#define SIMHACK_H

Flight CreateCampaignFlight(void);
Battalion CreateCampaignBattalion(void);
void AddSimEntityToUnit(Unit u, SimBaseClass *vehicle);

#endif
