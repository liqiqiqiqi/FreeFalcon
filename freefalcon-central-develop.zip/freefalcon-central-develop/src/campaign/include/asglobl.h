
#ifndef ASGLOBL
#define ASGLOBL


// A-Search is an A* Search algorythm which can be used to find the best-cost
// path between two nodes in a directed graph or a grid map (specialized directed
// graph, essentially

#endif
